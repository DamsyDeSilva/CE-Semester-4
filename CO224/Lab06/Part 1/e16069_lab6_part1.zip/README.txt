1.Compile
	iverilog -o cpu.vvp cpu_testbench.v

2.Run
	vvp cpu.vvp

3.Open with gtkwave tool
	gtkwave cpu_wavedata.vcd


NOTE:
	Previously submitted date : Wednesday, 3 June 2020, 8:20 PM
	New submitted date  : Saturday, 20 June 2020, 03:00 AM
	Changed files : alu.v , controlUnit.v, cpu_testbench.v	
