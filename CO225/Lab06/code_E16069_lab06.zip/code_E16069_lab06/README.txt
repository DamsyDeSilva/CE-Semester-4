
javac GameMain.java
java GameMain
