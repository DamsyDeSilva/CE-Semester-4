
public class Contact {
    private String fName;
    private String lName;
    private String cNum;

    //class constructor
    public Contact(String fName, String lName, String cNum ){
        this.fName = fName;
        this.lName = lName;
        this. cNum = cNum;
    }

    public String getFname() {
		return fName;
	}
    public String getlname() {
		return lName;
	}
    public String getContact() {
		return cNum;
	}
	

}